'use strict';

var P2JCMD = require('./lib/p2jcmd');
new P2JCMD().start();
